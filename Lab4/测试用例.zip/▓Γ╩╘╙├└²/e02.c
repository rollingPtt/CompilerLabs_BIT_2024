int main() {
    int i = 0;
    while (i < 3) {
        println_int(i);
        i = i + 1;
    }
    return 0;
}
