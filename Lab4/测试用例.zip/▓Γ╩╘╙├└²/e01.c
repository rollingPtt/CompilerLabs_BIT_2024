int main() {
    int a = 5, b = 3;
    if (a <= b) {
        println_int(a);
    }

    println_int(b);
    return 0;
}
